# =====================================================================
# Configuration: the only file you need to edit
# =====================================================================
# Run every script from the repository root (the folder that holds this file).
# Put the input files in data/ (see README.md for where to download each one).
# Outputs are written to results/.

DATA_DIR <- Sys.getenv("HYPOXIA_DATA_DIR", "data")
OUT_DIR  <- Sys.getenv("HYPOXIA_OUT_DIR",  "results")

# Input files
DATA_FILE <- file.path(DATA_DIR, "Water quality.csv")         # Sinha et al. (2026), Mendeley Data
WATERWAYS <- file.path(DATA_DIR, "waterways.geojson")         # OpenStreetMap waterways for Bangladesh (HOT export)
RASTER    <- file.path(DATA_DIR, "pollution_int.tif")         # Kaggle Bangladesh-River-Pollution-GIS raster
S2_FILE   <- file.path(OUT_DIR,  "s2_indices_per_sample.csv") # exported from Google Earth Engine (gee/)

# Model settings (these are the values used in the paper)
HYPOXIA_MGL    <- 2      # DO below this (mg/L) counts as hypoxic
RANGE_PRIOR_KM <- 15     # PC prior: P(spatial range < 15 km) = 0.5
SIGMA_PRIOR    <- c(3, 0.01)   # PC prior: P(spatial sd > 3) = 0.01
YEAR_PRIOR     <- c(3, 0.01)   # PC prior: P(year sd > 3) = 0.01

# Slow optional steps (leave-one-station-out cross-validation)
RUN_LOSO <- FALSE
